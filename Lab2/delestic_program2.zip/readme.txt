Hello!
To compile this project run the default make command
ie: $make
once the files have been populated you can run the program by running
$./output
to run with the sample script and valgrind you can use the makefile script
ie: $make valgrind
to clean the project use the makefile clean command
you can also make and run the file in valgrind with the makefile all command
ie: $make all
Thank you for your time and consideration!