Hello!
To compile this project run the default make command
ie: $make
once the files have been populated you can run the program by running
$./movies YOUR_FILE_HERE
to run with the sample script and valgrind you can use the makefile script
ie: $make valgrind