to run correctly, the user may need to use ^C to kill the process.
as there is an error currentyl in the code that causes the program to hang
when it is finished.
make sure to chmod +x ./p3testscript
it can be complied by running the command "make" in the directory
where the files are located.